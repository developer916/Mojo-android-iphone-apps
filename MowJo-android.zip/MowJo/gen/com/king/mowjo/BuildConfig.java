/** Automatically generated file. DO NOT MODIFY */
package com.king.mowjo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}