package com.king.mowjo.web;

import android.webkit.WebView;

public class JavaScriptInterface {    
	
	private final WebView m_wv;    
	
	public JavaScriptInterface(WebView wv) {       
		m_wv = wv;    
	}    
	
	public void reload() {       
		m_wv.reload();   
	} 
}