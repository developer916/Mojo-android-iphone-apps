package com.king.mowjo.web;

import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class CustomWebViewClient extends WebViewClient {
	
	private static int refreshCount;    
	private Context m_context;    
	private long m_start;
	
	public CustomWebViewClient(Context context) {       
		m_context = context;    
	}    
	
	@Override    
	public boolean shouldOverrideUrlLoading(WebView view, String url) {       
		return false;    
	}    
	
	@Override   
	public void onPageStarted(WebView view, String url, Bitmap favicon) {       
		m_start = System.currentTimeMillis();       
		refreshCount++;    
	}    
	
	@Override    
	public void onPageFinished(WebView view, String url) {      
		long interval = System.currentTimeMillis() - m_start;       
		/*Toast.makeText(m_context, "Loaded this webpage [" + refreshCount + "] " +               
		"times in [" + interval + "] ms", Toast.LENGTH_SHORT).show();*/    
	} 
}