package com.king.mowjo;


import com.king.mowjo.web.CustomChromeClient;
import com.king.mowjo.web.CustomWebViewClient;
import com.king.mowjo.web.JavaScriptInterface;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

@SuppressLint("JavascriptInterface")
public class WebviewActivity extends Activity {
	
	private static final String URL_TO_LOAD = "http://mowjo.com/";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		// Disable the title.
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// Full Screen
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		setContentView(R.layout.activity_browser);
		
		WebView wv = (WebView) findViewById(R.id.wv_browser);       
		loadResource(wv, URL_TO_LOAD);
	}
	
	private void loadResource(WebView wv, String resource) {      
		wv.loadUrl(resource);       
		wv.getSettings().setJavaScriptEnabled(true);       
		wv.setWebChromeClient(new CustomChromeClient());       
		wv.setWebViewClient(new CustomWebViewClient(this));       
		wv.addJavascriptInterface(new JavaScriptInterface(wv), "JSI");    
	} 
}