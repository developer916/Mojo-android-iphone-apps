//
//  ViewController.m
//  MowJo
//
//  Created by kingstar on 23/09/2015.
//  Copyright © 2015 Mr. RI. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

#define HOMEPAGE_URL        @"http://mowjo.com/"

@interface ViewController ()

@end

@implementation ViewController

@synthesize webView;
@synthesize loadingView;
@synthesize backButton;
@synthesize currentPageURL;
@synthesize beforePageURL;
@synthesize urlArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    webView.delegate = self;

    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://mowjo.com"]]];
    
    CGSize mainSize = [[UIScreen mainScreen] bounds].size;
    
    loadingView = [[UIView alloc]initWithFrame:CGRectMake((mainSize.width - 80) / 2, (mainSize.height - 80) / 2, 80, 80)];
    loadingView.backgroundColor = [UIColor colorWithWhite:0. alpha:0.6];
    loadingView.layer.cornerRadius = 5;
    
    UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activityView.center = CGPointMake(loadingView.frame.size.width / 2.0, 35);
    [activityView startAnimating];
    activityView.tag = 100;
    [loadingView addSubview:activityView];
    
    UILabel* lblLoading = [[UILabel alloc]initWithFrame:CGRectMake(0, 48, 80, 30)];
    lblLoading.text = @"Loading...";
    lblLoading.textColor = [UIColor whiteColor];
    lblLoading.font = [UIFont fontWithName:lblLoading.font.fontName size:15];
    lblLoading.textAlignment = NSTextAlignmentCenter;
    [loadingView addSubview:lblLoading];
    
    urlArray = [[NSMutableArray alloc] init];
    [urlArray addObject:HOMEPAGE_URL];
    
    
    backButton.hidden = YES;
    backButton.alpha = 0;
    currentPageURL = HOMEPAGE_URL;
    
    [self.view addSubview:loadingView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) showBackButton {
    
    backButton.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        backButton.alpha = 1;
    }];
    
}
- (void) hideBackButton {
    
    [UIView animateWithDuration:0.3 animations:^{
        backButton.alpha = 0;
    } completion: ^(BOOL finished) {//creates a variable (BOOL) called "finished" that is set to *YES* when animation IS completed.
        backButton.hidden = finished;//if animation is finished ("finished" == *YES*), then hidden = "finished" ... (aka hidden = *YES*)
    }];
}

#pragma mark - UIWebview Delegate Methods
- (void)webViewDidFinishLoad:(UIWebView *)currentWebView {
    currentPageURL = currentWebView.request.URL.absoluteString;
    
    if ([urlArray count] == 0) {
        [urlArray addObject:currentPageURL];
    }else {
        beforePageURL = [urlArray objectAtIndex:[urlArray count] - 1];
        if (![beforePageURL isEqualToString:currentPageURL]) {
            [urlArray addObject:currentPageURL];
        }
    }
    
    
    if ([currentPageURL isEqualToString:[NSString stringWithFormat:@"%@", HOMEPAGE_URL]]) {
        [self hideBackButton];
    }else {
        [self showBackButton];
    }
    
    [loadingView setHidden:YES];
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [loadingView setHidden:NO];
}

- (IBAction)onBackButton:(id)sender {

    beforePageURL = [urlArray objectAtIndex:[urlArray count] - 2];
    
    if ([beforePageURL isEqualToString:HOMEPAGE_URL]) {
        [self hideBackButton];
    }
    
    [urlArray removeLastObject];
    
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:beforePageURL]]];
}
@end
