//
//  ViewController.h
//  MowJo
//
//  Created by kingstar on 23/09/2015.
//  Copyright © 2015 Mr. RI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIWebViewDelegate> {
    UIView *loadingView;
    NSString *currentPageURL;
    NSString *beforePageURL;
    NSMutableArray *urlArray;
}

@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (nonatomic, retain) UIView *loadingView;
@property (strong, nonatomic) IBOutlet UIButton *backButton;
@property (nonatomic, retain) NSString *currentPageURL;
@property (nonatomic, retain) NSString *beforePageURL;
@property (nonatomic, retain) NSMutableArray *urlArray;

- (IBAction)onBackButton:(id)sender;
@end

