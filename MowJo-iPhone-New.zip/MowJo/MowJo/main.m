//
//  main.m
//  MowJo
//
//  Created by kingstar on 23/09/2015.
//  Copyright © 2015 Mr. RI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
