//
//  AppDelegate.h
//  MowJo
//
//  Created by kingstar on 23/09/2015.
//  Copyright © 2015 Mr. RI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

